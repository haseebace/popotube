---
url: "https://docs.bunny.net/stream/mediacage-basic"
title: "MediaCage Basic DRM - bunny.net Documentation"
---

[Skip to main content](https://docs.bunny.net/stream/mediacage-basic#content-area)

[bunny.net Documentation home page![light logo](https://mintcdn.com/bunnynet-cb9733c2/6384LvUK3LN5qH0K/logo/bunny-logo-dark.svg?fit=max&auto=format&n=6384LvUK3LN5qH0K&q=85&s=eba4147ce661ebcfa4c9c02824821548)![dark logo](https://mintcdn.com/bunnynet-cb9733c2/6384LvUK3LN5qH0K/logo/bunny-logo-light.svg?fit=max&auto=format&n=6384LvUK3LN5qH0K&q=85&s=70442c3230eb81060e645a47aebdcc32)](https://docs.bunny.net/)

Stream

[Documentation](https://docs.bunny.net/stream)

- [API Reference](https://docs.bunny.net/api-reference)
- [GitHub](https://github.com/BunnyWay)
- [Get Started](https://dash.bunny.net/auth/register)
- [Get Started](https://dash.bunny.net/auth/register)

Search...

Navigation

MediaCage DRM

MediaCage Basic DRM

Search...

Ctrl K

##### Documentation

- [Introduction](https://docs.bunny.net/stream)
- [Quickstart](https://docs.bunny.net/stream/quickstart)
- [Authentication](https://docs.bunny.net/stream/authentication)
- [Pricing](https://docs.bunny.net/stream/pricing)
- [Changelog](https://docs.bunny.net/stream/changelog)

##### Features

- Encoding

- [Premium Encoding](https://docs.bunny.net/stream/premium-encoding)
- [Transcribing](https://docs.bunny.net/stream/transcribing)
- [Smart Chapters](https://docs.bunny.net/stream/smart-chapters)
- MediaCage DRM

  - [Overview](https://docs.bunny.net/stream/drm)
  - [MediaCage Basic DRM](https://docs.bunny.net/stream/mediacage-basic)
  - [Understanding MediaCage basic DRM](https://docs.bunny.net/stream/mediacage-basic-guide)
  - [Quickstart MediaCage Basic DRM](https://docs.bunny.net/stream/quickstart-mediacage-basic)
  - [MediaCage Enterprise DRM](https://docs.bunny.net/stream/mediacage-enterprise)
  - [Quickstart MediaCage Enterprise DRM](https://docs.bunny.net/stream/quickstart-mediacage-enterprise)
  - [Google Widevine DRM](https://docs.bunny.net/stream/widevine-security-levels)
  - [Google Widevine DRM SD only for L3](https://docs.bunny.net/stream/widevine-l3)
  - [Apple FairPlay Streaming](https://docs.bunny.net/stream/fairplay-deployment)
- [Advertising VAST](https://docs.bunny.net/stream/vast)
- [Storage Tiers](https://docs.bunny.net/stream/storage-tiers)
- [Replication](https://docs.bunny.net/stream/replication)
- Security


##### Manage Videos

- Upload

- [Collections](https://docs.bunny.net/stream/collections)
- [Tagging](https://docs.bunny.net/stream/tagging)
- [MetaTags](https://docs.bunny.net/stream/metatags)
- [Storage Structure](https://docs.bunny.net/stream/storage-structure)

##### Playback

- Bunny Player

- 3rd Party Players

- Mobile SDK

- [Embedding videos](https://docs.bunny.net/stream/embedding)
- [MP4 Fallback](https://docs.bunny.net/stream/mp4-downloads)

##### Reference

- Tools

- [Statistics](https://docs.bunny.net/stream/statistics)
- [Webhooks](https://docs.bunny.net/stream/webhooks)
- [API Reference](https://docs.bunny.net/api-reference/stream)

On this page

- [What you’ll need](https://docs.bunny.net/stream/mediacage-basic#what-you%E2%80%99ll-need)
- [Enabling MediaCage Basic DRM](https://docs.bunny.net/stream/mediacage-basic#enabling-mediacage-basic-drm)
- [Limitations](https://docs.bunny.net/stream/mediacage-basic#limitations)
- [Embed view only](https://docs.bunny.net/stream/mediacage-basic#embed-view-only)
- [No MP4 fallback and Early-Play support](https://docs.bunny.net/stream/mediacage-basic#no-mp4-fallback-and-early-play-support)

MediaCage DRM

# MediaCage Basic DRM

MediaCage DRM Basic is a user-friendly feature that empowers every user to safeguard their video content effortlessly. It is designed with simplicity in mind, allowing users to enable DRM protection with just a few clicks through the dashboard. This feature ensures that your videos are protected from unauthorized access, providing you with the peace of mind that your valuable content remains secure.

# [​](https://docs.bunny.net/stream/mediacage-basic\#what-you%E2%80%99ll-need)  What you’ll need

Before you dive in, make sure you have the following prerequisites in place:

- A [bunny.net](https://bunny.net/) account ( [Log in](https://dash.bunny.net/auth/login?pk_buttonlocation=menu) or sign up for a [free trial](https://dash.bunny.net/auth/register)).

# [​](https://docs.bunny.net/stream/mediacage-basic\#enabling-mediacage-basic-drm)  Enabling MediaCage Basic DRM

Follow the steps below to easily enable the MediaCage Basic DRM feature and ensure seamless protection for your videos:

1. Login to [bunny.net dashboard](https://dash.bunny.net/auth/login?pk_buttonlocation=menu).
2. Click on **Stream** and select desired video library.

![](https://mintcdn.com/bunnynet-cb9733c2/hh4A9ppOP83enaFd/images/docs/d16bb3b-media-basic-stream.png?fit=max&auto=format&n=hh4A9ppOP83enaFd&q=85&s=61f91fb75b41bdb6e614fb911b10ddef)

3. Go to **Security tab**.

![](https://mintcdn.com/bunnynet-cb9733c2/FiSrqw57o-HOfhaQ/images/docs/5d0c897-media-basic-security.png?fit=max&auto=format&n=FiSrqw57o-HOfhaQ&q=85&s=7cf8c78fbe0d3fc3da623d8523331b14)

4. In the **Security tab**, you will find the DRM toggle switch. Simply toggle it on to enable DRM protection for the selected video library.

![](https://mintcdn.com/bunnynet-cb9733c2/67qULoyM94F_v9Yh/images/docs/03ffade-drm-enable.png?fit=max&auto=format&n=67qULoyM94F_v9Yh&q=85&s=9b498414aebba567f4b69066492f1620)After MediaCage Basic DRM is enabled on video library, the media files are instantly protected by employing the dynamic encryption when accessing the media files.

# [​](https://docs.bunny.net/stream/mediacage-basic\#limitations)  Limitations

MediaCage DRM is designed to provide a robust security framework for your digital media content. However, to maintain the highest level of protection, there are certain functional limitations that you need to be aware of:

## [​](https://docs.bunny.net/stream/mediacage-basic\#embed-view-only)  Embed view only

MediaCage strictly enforces content playback through its proprietary Embed View. This means that any attempts to access or play videos directly from the file storage or through third-party video players are not supported and will be automatically disabled. This restriction ensures that all content remains within the secure environment of MediaCage, preventing unauthorized access and distribution.

## [​](https://docs.bunny.net/stream/mediacage-basic\#no-mp4-fallback-and-early-play-support)  No MP4 fallback and Early-Play support

MediaCage does not support MP4 fallback and Early-Play features when activated on a video library. These features are often susceptible to security vulnerabilities, including unauthorized downloads and premature content access. By disabling these options, MediaCage enhances the security of the media content, ensuring that all playback adheres strictly to the established DRM protocols and cannot be circumvented.These limitations are put in place to ensure that MediaCage can offer the most secure and controlled environment for hosting and sharing digital media content.

Was this page helpful?

YesNo

[MediaCage DRM\\
\\
Previous](https://docs.bunny.net/stream/drm) [Understanding MediaCage basic DRM\\
\\
Next](https://docs.bunny.net/stream/mediacage-basic-guide)

Ctrl+I

[discord](https://discord.gg/bunnynet) [github](https://github.com/BunnyWay) [x](https://x.com/BunnyCDN) [bluesky](https://bsky.app/profile/bunny.net) [linkedin](https://www.linkedin.com/company/bunnynet) [facebook](https://www.facebook.com/bunnycdn)

[Powered byThis documentation is built and hosted on Mintlify, a developer documentation platform](https://www.mintlify.com/?utm_campaign=poweredBy&utm_medium=referral&utm_source=bunnynet-cb9733c2)

![](https://mintcdn.com/bunnynet-cb9733c2/hh4A9ppOP83enaFd/images/docs/d16bb3b-media-basic-stream.png?w=840&fit=max&auto=format&n=hh4A9ppOP83enaFd&q=85&s=4be0957c558589dd87f9ce7c480046b0)

![](https://mintcdn.com/bunnynet-cb9733c2/FiSrqw57o-HOfhaQ/images/docs/5d0c897-media-basic-security.png?w=840&fit=max&auto=format&n=FiSrqw57o-HOfhaQ&q=85&s=7ae81c7a69181ac8714822aa80252638)

![](https://mintcdn.com/bunnynet-cb9733c2/67qULoyM94F_v9Yh/images/docs/03ffade-drm-enable.png?w=840&fit=max&auto=format&n=67qULoyM94F_v9Yh&q=85&s=aee9eead13998400c964ad278f597518)