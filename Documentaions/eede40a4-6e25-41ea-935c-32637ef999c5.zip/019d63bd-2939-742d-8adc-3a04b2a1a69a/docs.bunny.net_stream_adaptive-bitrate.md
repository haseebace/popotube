---
url: "https://docs.bunny.net/stream/adaptive-bitrate"
title: "Adaptive bitrate streaming - bunny.net Documentation"
---

[Skip to main content](https://docs.bunny.net/stream/adaptive-bitrate#content-area)

[bunny.net Documentation home page![light logo](https://mintcdn.com/bunnynet-cb9733c2/6384LvUK3LN5qH0K/logo/bunny-logo-dark.svg?fit=max&auto=format&n=6384LvUK3LN5qH0K&q=85&s=eba4147ce661ebcfa4c9c02824821548)![dark logo](https://mintcdn.com/bunnynet-cb9733c2/6384LvUK3LN5qH0K/logo/bunny-logo-light.svg?fit=max&auto=format&n=6384LvUK3LN5qH0K&q=85&s=70442c3230eb81060e645a47aebdcc32)](https://docs.bunny.net/)

Stream

[Documentation](https://docs.bunny.net/stream)

- [API Reference](https://docs.bunny.net/api-reference)
- [GitHub](https://github.com/BunnyWay)
- [Get Started](https://dash.bunny.net/auth/register)
- [Get Started](https://dash.bunny.net/auth/register)

Search...

Navigation

Encoding

Adaptive bitrate streaming

Search...

Ctrl K

##### Documentation

- [Introduction](https://docs.bunny.net/stream)
- [Quickstart](https://docs.bunny.net/stream/quickstart)
- [Authentication](https://docs.bunny.net/stream/authentication)
- [Pricing](https://docs.bunny.net/stream/pricing)
- [Changelog](https://docs.bunny.net/stream/changelog)

##### Features

- Encoding

  - [Overview](https://docs.bunny.net/stream/encoding)
  - [Video specification](https://docs.bunny.net/stream/video-specification)
  - [Adaptive bitrate streaming](https://docs.bunny.net/stream/adaptive-bitrate)
  - [Multi-audio](https://docs.bunny.net/stream/multi-audio)
- [Premium Encoding](https://docs.bunny.net/stream/premium-encoding)
- [Transcribing](https://docs.bunny.net/stream/transcribing)
- [Smart Chapters](https://docs.bunny.net/stream/smart-chapters)
- MediaCage DRM

- [Advertising VAST](https://docs.bunny.net/stream/vast)
- [Storage Tiers](https://docs.bunny.net/stream/storage-tiers)
- [Replication](https://docs.bunny.net/stream/replication)
- Security


##### Manage Videos

- Upload

- [Collections](https://docs.bunny.net/stream/collections)
- [Tagging](https://docs.bunny.net/stream/tagging)
- [MetaTags](https://docs.bunny.net/stream/metatags)
- [Storage Structure](https://docs.bunny.net/stream/storage-structure)

##### Playback

- Bunny Player

- 3rd Party Players

- Mobile SDK

- [Embedding videos](https://docs.bunny.net/stream/embedding)
- [MP4 Fallback](https://docs.bunny.net/stream/mp4-downloads)

##### Reference

- Tools

- [Statistics](https://docs.bunny.net/stream/statistics)
- [Webhooks](https://docs.bunny.net/stream/webhooks)
- [API Reference](https://docs.bunny.net/api-reference/stream)

On this page

- [Bitrate in video streaming](https://docs.bunny.net/stream/adaptive-bitrate#bitrate-in-video-streaming)
- [Encoding](https://docs.bunny.net/stream/adaptive-bitrate#encoding)
- [Resolution](https://docs.bunny.net/stream/adaptive-bitrate#resolution)
- [Framerate](https://docs.bunny.net/stream/adaptive-bitrate#framerate)
- [Adaptive bitrate streaming](https://docs.bunny.net/stream/adaptive-bitrate#adaptive-bitrate-streaming)

Encoding

# Adaptive bitrate streaming

In the world of computing, particularly within the realm of streaming, the concept of bitrate is fundamental. Bitrate, or bit rate, represents the volume of bits transferred or processed over a given unit of time. Typically measured in bits per second (bps), this metric is pivotal in determining the quality of media, be it audio or video, streamed across a network. It’s crucial to distinguish between bits per second (bps) and bytes per second (Bps) as they signify different aspects: bps measures uploading or downloading speed, whereas Bps quantifies the amount of data transferred.

# [​](https://docs.bunny.net/stream/adaptive-bitrate\#bitrate-in-video-streaming)  Bitrate in video streaming

For video content, a higher bitrate is synonymous with improved image quality, thanks to the greater volume of data transmitted per time unit. This not only affects the video file’s size for local viewing but also determines the requisite network bandwidth for users to enjoy a seamless streaming experience. The following table illustrates approximate video bitrates for various common resolutions:![](https://mintcdn.com/bunnynet-cb9733c2/FiSrqw57o-HOfhaQ/images/docs/42fbe40-image.png?fit=max&auto=format&n=FiSrqw57o-HOfhaQ&q=85&s=a66eb10274d186f72639d28b9000c361)The essence of video quality also hinges on adaptive bitrate streaming, alongside specific encoding, resolution, and framerate parameters.

# [​](https://docs.bunny.net/stream/adaptive-bitrate\#encoding)  Encoding

Encoding transforms digital video into a specific format by identifying patterns within the video. It replaces repetitive elements with references, thereby reducing file size or the required bitrate. While lossless compression allows for a perfect reconstruction of the original video, lossy compression eliminates deemed unnecessary information, which cannot be recovered later. Lossy compression is generally preferred for encoding video to store as much visual data as possible into fewer bits. The efficacy of encoding depends on the algorithm’s settings, its computational complexity, and the available hardware and software support.

# [​](https://docs.bunny.net/stream/adaptive-bitrate\#resolution)  Resolution

Resolution specifies the pixel count constituting a single video frame. Typically, higher resolutions mean a sharper image and enhanced video quality, improving the viewing experience on larger displays. Resolution is denoted by the formula Width x Height, indicating the total number of pixels. For instance, a resolution of 480 x 360 equates to 172,800 pixels. In broadcasting and video players, resolutions are often represented only by their height (e.g., 480, 720, 1080).

# [​](https://docs.bunny.net/stream/adaptive-bitrate\#framerate)  Framerate

Framerate, or frames per second (fps), dictates the frequency at which video frames are displayed, creating the illusion of motion. While 24 fps is standard for most video formats, content with rapid movements might benefit from higher framerates, ranging from 30 to 60 fps.

# [​](https://docs.bunny.net/stream/adaptive-bitrate\#adaptive-bitrate-streaming)  Adaptive bitrate streaming

Adaptive bitrate streaming optimizes video resolution and framerate based on the viewer’s network bandwidth. This technology allows users with high bandwidth to enjoy high-quality streams, whereas those with limited bandwidth can reduce the resolution and framerate to suit their constraints. Adaptive bitrate streaming enhances the user experience by minimizing buffering and ensuring smooth playback under varying network condition

Was this page helpful?

YesNo

[Video specification\\
\\
Previous](https://docs.bunny.net/stream/video-specification) [Multi-audio\\
\\
Next](https://docs.bunny.net/stream/multi-audio)

Ctrl+I

[discord](https://discord.gg/bunnynet) [github](https://github.com/BunnyWay) [x](https://x.com/BunnyCDN) [bluesky](https://bsky.app/profile/bunny.net) [linkedin](https://www.linkedin.com/company/bunnynet) [facebook](https://www.facebook.com/bunnycdn)

[Powered byThis documentation is built and hosted on Mintlify, a developer documentation platform](https://www.mintlify.com/?utm_campaign=poweredBy&utm_medium=referral&utm_source=bunnynet-cb9733c2)

![](https://mintcdn.com/bunnynet-cb9733c2/FiSrqw57o-HOfhaQ/images/docs/42fbe40-image.png?w=840&fit=max&auto=format&n=FiSrqw57o-HOfhaQ&q=85&s=dab2f8fc65fc8ba22cf3b3273dfb3323)