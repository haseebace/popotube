---
url: "https://docs.bunny.net/stream/token-authentication"
title: "Embedded view token authentication - bunny.net Documentation"
---

[Skip to main content](https://docs.bunny.net/stream/token-authentication#content-area)

[bunny.net Documentation home page![light logo](https://mintcdn.com/bunnynet-cb9733c2/6384LvUK3LN5qH0K/logo/bunny-logo-dark.svg?fit=max&auto=format&n=6384LvUK3LN5qH0K&q=85&s=eba4147ce661ebcfa4c9c02824821548)![dark logo](https://mintcdn.com/bunnynet-cb9733c2/6384LvUK3LN5qH0K/logo/bunny-logo-light.svg?fit=max&auto=format&n=6384LvUK3LN5qH0K&q=85&s=70442c3230eb81060e645a47aebdcc32)](https://docs.bunny.net/)

Stream

[Documentation](https://docs.bunny.net/stream)

- [API Reference](https://docs.bunny.net/api-reference)
- [GitHub](https://github.com/BunnyWay)
- [Get Started](https://dash.bunny.net/auth/register)
- [Get Started](https://dash.bunny.net/auth/register)

Search...

Navigation

Security

Embedded view token authentication

Search...

Ctrl K

##### Documentation

- [Introduction](https://docs.bunny.net/stream)
- [Quickstart](https://docs.bunny.net/stream/quickstart)
- [Authentication](https://docs.bunny.net/stream/authentication)
- [Pricing](https://docs.bunny.net/stream/pricing)
- [Changelog](https://docs.bunny.net/stream/changelog)

##### Features

- Encoding

- [Premium Encoding](https://docs.bunny.net/stream/premium-encoding)
- [Transcribing](https://docs.bunny.net/stream/transcribing)
- [Smart Chapters](https://docs.bunny.net/stream/smart-chapters)
- MediaCage DRM

- [Advertising VAST](https://docs.bunny.net/stream/vast)
- [Storage Tiers](https://docs.bunny.net/stream/storage-tiers)
- [Replication](https://docs.bunny.net/stream/replication)
- Security

  - [Security](https://docs.bunny.net/stream/security)
  - [Understanding Bunny Stream security options](https://docs.bunny.net/stream/security-options)
  - [Embedded view token authentication](https://docs.bunny.net/stream/token-authentication)

##### Manage Videos

- Upload

- [Collections](https://docs.bunny.net/stream/collections)
- [Tagging](https://docs.bunny.net/stream/tagging)
- [MetaTags](https://docs.bunny.net/stream/metatags)
- [Storage Structure](https://docs.bunny.net/stream/storage-structure)

##### Playback

- Bunny Player

- 3rd Party Players

- Mobile SDK

- [Embedding videos](https://docs.bunny.net/stream/embedding)
- [MP4 Fallback](https://docs.bunny.net/stream/mp4-downloads)

##### Reference

- Tools

- [Statistics](https://docs.bunny.net/stream/statistics)
- [Webhooks](https://docs.bunny.net/stream/webhooks)
- [API Reference](https://docs.bunny.net/api-reference/stream)

On this page

- [What is the embed view token authentication?](https://docs.bunny.net/stream/token-authentication#what-is-the-embed-view-token-authentication)
- [Signing procedure](https://docs.bunny.net/stream/token-authentication#signing-procedure)

Security

# Embedded view token authentication

Secure your video embeds with token authentication to prevent unauthorized playback.

# [​](https://docs.bunny.net/stream/token-authentication\#what-is-the-embed-view-token-authentication)  What is the embed view token authentication?

The Embed View Token Authentication allows you to secure your iframe to prevent unauthorized embedding of your videos.

# [​](https://docs.bunny.net/stream/token-authentication\#signing-procedure)  Signing procedure

To create a secure URL, you must add a **token** and **expires** query parameters to the URL that you want to access. The expires parameter is the UNIX timestamp in seconds marking until when the URL is accessible. Milliseconds and nanoseconds are not supported. After this passes, the URL will no longer be accessible.The token parameter is a HEX value of the SHA256 hash based on the key, video ID and expiration time. To generate the token, you can use the following algorithm.

SHA256\_HEX

SHA256

```
SHA256_HEX(token_security_key + video_id + expiration)
```

An example secure URL will then look like:

```
https://iframe.mediadelivery.net/embed/759/eb1c4f77-0cda-46be-b47d-1118ad7c2ffe?token=5a5de480db5d14ed30717a3e849c7148a998fa42b0c267774756558e2de99eee&expires=1456761770
```

Similarly, the MediaCage Enterprise DRM license service endpoint URL example looks like:

```
https://video.bunnycdn.com/FairPlayLicense/759/eb1c4f77-0cda-46be-b47d-1118ad7c2ffe?token=5a5de480db5d14ed30717a3e849c7148a998fa42b0c267774756558e2de99eee&expires=1456761770
```

Was this page helpful?

YesNo

[Understanding Bunny Stream security options\\
\\
Previous](https://docs.bunny.net/stream/security-options) [Dashboard\\
\\
Next](https://docs.bunny.net/stream/dashboard)

Ctrl+I

[discord](https://discord.gg/bunnynet) [github](https://github.com/BunnyWay) [x](https://x.com/BunnyCDN) [bluesky](https://bsky.app/profile/bunny.net) [linkedin](https://www.linkedin.com/company/bunnynet) [facebook](https://www.facebook.com/bunnycdn)

[Powered byThis documentation is built and hosted on Mintlify, a developer documentation platform](https://www.mintlify.com/?utm_campaign=poweredBy&utm_medium=referral&utm_source=bunnynet-cb9733c2)