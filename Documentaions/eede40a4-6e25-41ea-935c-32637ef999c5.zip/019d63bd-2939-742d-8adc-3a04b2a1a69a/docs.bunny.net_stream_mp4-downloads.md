---
url: "https://docs.bunny.net/stream/mp4-downloads"
title: "MP4 Fallback - bunny.net Documentation"
---

[Skip to main content](https://docs.bunny.net/stream/mp4-downloads#content-area)

[bunny.net Documentation home page![light logo](https://mintcdn.com/bunnynet-cb9733c2/6384LvUK3LN5qH0K/logo/bunny-logo-dark.svg?fit=max&auto=format&n=6384LvUK3LN5qH0K&q=85&s=eba4147ce661ebcfa4c9c02824821548)![dark logo](https://mintcdn.com/bunnynet-cb9733c2/6384LvUK3LN5qH0K/logo/bunny-logo-light.svg?fit=max&auto=format&n=6384LvUK3LN5qH0K&q=85&s=70442c3230eb81060e645a47aebdcc32)](https://docs.bunny.net/)

Stream

[Documentation](https://docs.bunny.net/stream)

- [API Reference](https://docs.bunny.net/api-reference)
- [GitHub](https://github.com/BunnyWay)
- [Get Started](https://dash.bunny.net/auth/register)
- [Get Started](https://dash.bunny.net/auth/register)

Search...

Navigation

Playback

MP4 Fallback

Search...

Ctrl K

##### Documentation

- [Introduction](https://docs.bunny.net/stream)
- [Quickstart](https://docs.bunny.net/stream/quickstart)
- [Authentication](https://docs.bunny.net/stream/authentication)
- [Pricing](https://docs.bunny.net/stream/pricing)
- [Changelog](https://docs.bunny.net/stream/changelog)

##### Features

- Encoding

- [Premium Encoding](https://docs.bunny.net/stream/premium-encoding)
- [Transcribing](https://docs.bunny.net/stream/transcribing)
- [Smart Chapters](https://docs.bunny.net/stream/smart-chapters)
- MediaCage DRM

- [Advertising VAST](https://docs.bunny.net/stream/vast)
- [Storage Tiers](https://docs.bunny.net/stream/storage-tiers)
- [Replication](https://docs.bunny.net/stream/replication)
- Security


##### Manage Videos

- Upload

- [Collections](https://docs.bunny.net/stream/collections)
- [Tagging](https://docs.bunny.net/stream/tagging)
- [MetaTags](https://docs.bunny.net/stream/metatags)
- [Storage Structure](https://docs.bunny.net/stream/storage-structure)

##### Playback

- Bunny Player

- 3rd Party Players

- Mobile SDK

- [Embedding videos](https://docs.bunny.net/stream/embedding)
- [MP4 Fallback](https://docs.bunny.net/stream/mp4-downloads)

##### Reference

- Tools

- [Statistics](https://docs.bunny.net/stream/statistics)
- [Webhooks](https://docs.bunny.net/stream/webhooks)
- [API Reference](https://docs.bunny.net/api-reference/stream)

On this page

- [Prerequisites](https://docs.bunny.net/stream/mp4-downloads#prerequisites)
- [How to retrieve the MP4 URL?](https://docs.bunny.net/stream/mp4-downloads#how-to-retrieve-the-mp4-url)
- [Troubleshooting](https://docs.bunny.net/stream/mp4-downloads#troubleshooting)

Playback

# MP4 Fallback

The bunny.net Stream platform offers MP4 URL access to some resolutions of video enabled, which may be useful in an environment where HLS playback or using our player is not possible (e.g. for legacy devices).

## [​](https://docs.bunny.net/stream/mp4-downloads\#prerequisites)  Prerequisites

- You must have a [Video Library created](https://docs.bunny.net/stream/quickstart#creating-a-video-library).
- You need to have MP4 Fallback enabled under the encoding tab of the created video library

![Enable MP4 Fallback](https://mintcdn.com/bunnynet-cb9733c2/mSKHqNspUGqE8b_K/images/stream/enable-mp4-fallback.png?fit=max&auto=format&n=mSKHqNspUGqE8b_K&q=85&s=cb1af33f064ac200648a9f4452566a0f)

- **Only videos uploaded after enabling MP4 Fallback will generate the MP4 file. Please keep in mind that the fallbacks go up to a maximum of 1080P in quality if the original permits.**
- In addition to the above, we do not upscale videos. A 1080P fallback for example cannot be generated if the maximum quality of the original video is 480P, but in that case then play\_480p.mp4 would work.

## [​](https://docs.bunny.net/stream/mp4-downloads\#how-to-retrieve-the-mp4-url)  How to retrieve the MP4 URL?

1

[Navigate to header](https://docs.bunny.net/stream/mp4-downloads#)

Open your video

Navigate to your video in the Stream dashboard.

2

[Navigate to header](https://docs.bunny.net/stream/mp4-downloads#)

Expand MP4 URLs

MP4 URLs will appear on your video page - click to expand.

![Expand MP4 URLs](https://mintcdn.com/bunnynet-cb9733c2/mSKHqNspUGqE8b_K/images/stream/mp4-fallback-video-details.png?fit=max&auto=format&n=mSKHqNspUGqE8b_K&q=85&s=5ed09a4ab737d896063e8704a2f45d37)

3

[Navigate to header](https://docs.bunny.net/stream/mp4-downloads#)

Copy or download

You can now copy each MP4 resolution URL link or download the MP4 locally.

![MP4 URLs](https://mintcdn.com/bunnynet-cb9733c2/mSKHqNspUGqE8b_K/images/stream/mp4-fallback-urls.png?fit=max&auto=format&n=mSKHqNspUGqE8b_K&q=85&s=5217983c9ff687c9c8c7a47bf02d5f97)

Assuming that the above eligibility criteria have been satisfied, you can generate an MP4 URL employing the subsequent structure:

```
https://pull_zone_url.b-cdn.net/video_id/play_{ResolutionHeight}p.mp4
```

While producing the above mentioned URL, it is critical to bear in mind that the fallback selections are only up to 1080p. It may be easier to copy/paste the HLS URL and then change the file on the end to the MP4 URL. Thus, any resolution that is higher than 1080p, such as 2160p, will trigger a 404 error because it is not present. If you only have one resolution enabled (for example, 2160p only (and nothing else) then we will generate an MP4 URL for that resolution).The final link should appear as follows:

```
https://pull_zone_url.b-cdn.net/video_id/play_1080p.mp4
```

## [​](https://docs.bunny.net/stream/mp4-downloads\#troubleshooting)  Troubleshooting

I can't see my MP4 URLs or I'm getting a 403 error

Review your security settings, as they are likely the cause:

- Token authentication is enabled, but you are not producing a token or creating it incorrectly.
- Allowed domains are specified, restricting video playback to only authorized domains.
- Direct URL file access is denied. If you type the URL into your browser’s address bar, you’ll get a 403 error since you’re attempting to access it directly. This is common on Apple devices, which do not send the correct referrer headers.

I'm getting a 404 error

This is most likely due to one of two things:

- An incorrect URL construction.
- The fallback resolution you want to use does not exist.

Was this page helpful?

YesNo

[Embedding videos\\
\\
Previous](https://docs.bunny.net/stream/embedding) [Vimeo2Bunny CLI\\
\\
Next](https://docs.bunny.net/stream/vimeo2bunny)

Ctrl+I

[discord](https://discord.gg/bunnynet) [github](https://github.com/BunnyWay) [x](https://x.com/BunnyCDN) [bluesky](https://bsky.app/profile/bunny.net) [linkedin](https://www.linkedin.com/company/bunnynet) [facebook](https://www.facebook.com/bunnycdn)

[Powered byThis documentation is built and hosted on Mintlify, a developer documentation platform](https://www.mintlify.com/?utm_campaign=poweredBy&utm_medium=referral&utm_source=bunnynet-cb9733c2)

![Enable MP4 Fallback](https://mintcdn.com/bunnynet-cb9733c2/mSKHqNspUGqE8b_K/images/stream/enable-mp4-fallback.png?w=840&fit=max&auto=format&n=mSKHqNspUGqE8b_K&q=85&s=a611f6493e39310dd1acb296866050d3)

![Expand MP4 URLs](https://mintcdn.com/bunnynet-cb9733c2/mSKHqNspUGqE8b_K/images/stream/mp4-fallback-video-details.png?w=840&fit=max&auto=format&n=mSKHqNspUGqE8b_K&q=85&s=c74c0318e7c678869b0df090b84f31e8)

![MP4 URLs](https://mintcdn.com/bunnynet-cb9733c2/mSKHqNspUGqE8b_K/images/stream/mp4-fallback-urls.png?w=840&fit=max&auto=format&n=mSKHqNspUGqE8b_K&q=85&s=49e178e9a276f14bfba578f80165a784)