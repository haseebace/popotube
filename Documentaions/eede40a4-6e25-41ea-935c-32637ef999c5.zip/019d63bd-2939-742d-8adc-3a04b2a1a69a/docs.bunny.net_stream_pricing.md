---
url: "https://docs.bunny.net/stream/pricing"
title: "Pricing - bunny.net Documentation"
---

[Skip to main content](https://docs.bunny.net/stream/pricing#content-area)

[bunny.net Documentation home page![light logo](https://mintcdn.com/bunnynet-cb9733c2/6384LvUK3LN5qH0K/logo/bunny-logo-dark.svg?fit=max&auto=format&n=6384LvUK3LN5qH0K&q=85&s=eba4147ce661ebcfa4c9c02824821548)![dark logo](https://mintcdn.com/bunnynet-cb9733c2/6384LvUK3LN5qH0K/logo/bunny-logo-light.svg?fit=max&auto=format&n=6384LvUK3LN5qH0K&q=85&s=70442c3230eb81060e645a47aebdcc32)](https://docs.bunny.net/)

Stream

[Documentation](https://docs.bunny.net/stream)

- [API Reference](https://docs.bunny.net/api-reference)
- [GitHub](https://github.com/BunnyWay)
- [Get Started](https://dash.bunny.net/auth/register)
- [Get Started](https://dash.bunny.net/auth/register)

Search...

Navigation

Documentation

Pricing

Search...

Ctrl K

##### Documentation

- [Introduction](https://docs.bunny.net/stream)
- [Quickstart](https://docs.bunny.net/stream/quickstart)
- [Authentication](https://docs.bunny.net/stream/authentication)
- [Pricing](https://docs.bunny.net/stream/pricing)
- [Changelog](https://docs.bunny.net/stream/changelog)

##### Features

- Encoding

- [Premium Encoding](https://docs.bunny.net/stream/premium-encoding)
- [Transcribing](https://docs.bunny.net/stream/transcribing)
- [Smart Chapters](https://docs.bunny.net/stream/smart-chapters)
- MediaCage DRM

- [Advertising VAST](https://docs.bunny.net/stream/vast)
- [Storage Tiers](https://docs.bunny.net/stream/storage-tiers)
- [Replication](https://docs.bunny.net/stream/replication)
- Security


##### Manage Videos

- Upload

- [Collections](https://docs.bunny.net/stream/collections)
- [Tagging](https://docs.bunny.net/stream/tagging)
- [MetaTags](https://docs.bunny.net/stream/metatags)
- [Storage Structure](https://docs.bunny.net/stream/storage-structure)

##### Playback

- Bunny Player

- 3rd Party Players

- Mobile SDK

- [Embedding videos](https://docs.bunny.net/stream/embedding)
- [MP4 Fallback](https://docs.bunny.net/stream/mp4-downloads)

##### Reference

- Tools

- [Statistics](https://docs.bunny.net/stream/statistics)
- [Webhooks](https://docs.bunny.net/stream/webhooks)
- [API Reference](https://docs.bunny.net/api-reference/stream)

On this page

- [Premium Encoding](https://docs.bunny.net/stream/pricing#premium-encoding)
- [Transcribing](https://docs.bunny.net/stream/pricing#transcribing)
- [$0.10 per language minute](https://docs.bunny.net/stream/pricing#%240-10-per-language-minute)
- [MediaCage Enterprise DRM](https://docs.bunny.net/stream/pricing#mediacage-enterprise-drm)
- [$99 per month base fee](https://docs.bunny.net/stream/pricing#%2499-per-month-base-fee)
- [Stream Storage and CDN Calculator](https://docs.bunny.net/stream/pricing#stream-storage-and-cdn-calculator)
- [Storage HDD](https://docs.bunny.net/stream/pricing#storage-hdd)
- [GEO Replication](https://docs.bunny.net/stream/pricing#geo-replication)
- [CDN](https://docs.bunny.net/stream/pricing#cdn)
- [Standard network](https://docs.bunny.net/stream/pricing#standard-network)
- [Volume network](https://docs.bunny.net/stream/pricing#volume-network)

Documentation

# Pricing

Bunny Stream pricing for encoding, transcribing, DRM, storage, and CDN delivery.

# [​](https://docs.bunny.net/stream/pricing\#premium-encoding)  Premium Encoding

| Resolution | Encoding cost per minute |
| --- | --- |
| 2160p (UHD 3840 x 2160) 1440p (QHD 2560 x 1440) | $0.150 |
| 1080p (FHD 1920 x 1080) 720p (HD 1280 x 720) | $0.050 |
| 480p (ED 842 x 480) 360p (nHD 640 x 360) 240p (EGA 352 x 240) | $0.025 |

# [​](https://docs.bunny.net/stream/pricing\#transcribing)  Transcribing

### [​](https://docs.bunny.net/stream/pricing\#$0-10-per-language-minute)  $0.10 per language minute

Each language selected will cost $0.10 per minute to transcribe with AI.Example: The video is 10 minutes long and both English and French have been selected for transcribing. The total will cost you $2.00 to transcribe.($0.10 × 10 minutes) × 2 languages = $2.00

# [​](https://docs.bunny.net/stream/pricing\#mediacage-enterprise-drm)  MediaCage Enterprise DRM

### [​](https://docs.bunny.net/stream/pricing\#$99-per-month-base-fee)  $99 per month base fee

| DRM licenses issued per month | Cost per DRM license issued |
| --- | --- |
| 0 to 20,000 | $0.005 |
| 20,001 to 100,000 | $0.004 |
| 100,001 to 500,000 | $0.003 |
| 500,000 + | Please contact sales for custom pricing |

**Multi-key DRM Licensing**Multi-key DRM licensing is implemented on a per-playback-device basis, allowing multiple licenses to be issued for a single piece of video content.For example, a single playback device may receive two separate licenses. One for the video stream and another for the accompanying stereo audio track; resulting in a total of two DRM licenses being issued and billed.

# [​](https://docs.bunny.net/stream/pricing\#stream-storage-and-cdn-calculator)  [Stream Storage and CDN Calculator](https://bunny.net/pricing/stream/\#:~:text=Calculate%20your%20monthly%20bill)

## [​](https://docs.bunny.net/stream/pricing\#storage-hdd)  Storage HDD

| Default region | Storage cost per GB |
| --- | --- |
| Europe - Frankfurt (DE) | $0.01 |

## [​](https://docs.bunny.net/stream/pricing\#geo-replication)  GEO Replication

| Additional regions | Storage cost per GB |
| --- | --- |
| 2nd region | $0.01 |
| 3rd region + | $0.005 |

# [​](https://docs.bunny.net/stream/pricing\#cdn)  [CDN](https://bunny.net/pricing/cdn/)

## [​](https://docs.bunny.net/stream/pricing\#standard-network)  Standard network

| Region | Cost per GB |
| --- | --- |
| Europe & North America | $0.010 |
| South America | $0.045 |
| Asia & Oceania | $0.030 |
| Middle East & Africa | $0.060 |

## [​](https://docs.bunny.net/stream/pricing\#volume-network)  Volume network

| Data transfer per month | Cost per GB |
| --- | --- |
| 0 to 500 TB | $0.005 |
| 500 TB to 1000 TB | $0.004 |
| 1000 TB to 2000 TB | $0.002 |
| 2000 TB+ | Please contact sales |

Was this page helpful?

YesNo

[Authentication\\
\\
Previous](https://docs.bunny.net/stream/authentication) [Changelog\\
\\
Next](https://docs.bunny.net/stream/changelog)

Ctrl+I

[discord](https://discord.gg/bunnynet) [github](https://github.com/BunnyWay) [x](https://x.com/BunnyCDN) [bluesky](https://bsky.app/profile/bunny.net) [linkedin](https://www.linkedin.com/company/bunnynet) [facebook](https://www.facebook.com/bunnycdn)

[Powered byThis documentation is built and hosted on Mintlify, a developer documentation platform](https://www.mintlify.com/?utm_campaign=poweredBy&utm_medium=referral&utm_source=bunnynet-cb9733c2)