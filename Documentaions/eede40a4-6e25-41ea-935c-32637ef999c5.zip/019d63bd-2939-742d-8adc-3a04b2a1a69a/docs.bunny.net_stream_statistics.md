---
url: "https://docs.bunny.net/stream/statistics"
title: "Statistics - bunny.net Documentation"
---

[Skip to main content](https://docs.bunny.net/stream/statistics#content-area)

[bunny.net Documentation home page![light logo](https://mintcdn.com/bunnynet-cb9733c2/6384LvUK3LN5qH0K/logo/bunny-logo-dark.svg?fit=max&auto=format&n=6384LvUK3LN5qH0K&q=85&s=eba4147ce661ebcfa4c9c02824821548)![dark logo](https://mintcdn.com/bunnynet-cb9733c2/6384LvUK3LN5qH0K/logo/bunny-logo-light.svg?fit=max&auto=format&n=6384LvUK3LN5qH0K&q=85&s=70442c3230eb81060e645a47aebdcc32)](https://docs.bunny.net/)

Stream

[Documentation](https://docs.bunny.net/stream)

- [API Reference](https://docs.bunny.net/api-reference)
- [GitHub](https://github.com/BunnyWay)
- [Get Started](https://dash.bunny.net/auth/register)
- [Get Started](https://dash.bunny.net/auth/register)

Search...

Navigation

Reference

Statistics

Search...

Ctrl K

##### Documentation

- [Introduction](https://docs.bunny.net/stream)
- [Quickstart](https://docs.bunny.net/stream/quickstart)
- [Authentication](https://docs.bunny.net/stream/authentication)
- [Pricing](https://docs.bunny.net/stream/pricing)
- [Changelog](https://docs.bunny.net/stream/changelog)

##### Features

- Encoding

- [Premium Encoding](https://docs.bunny.net/stream/premium-encoding)
- [Transcribing](https://docs.bunny.net/stream/transcribing)
- [Smart Chapters](https://docs.bunny.net/stream/smart-chapters)
- MediaCage DRM

- [Advertising VAST](https://docs.bunny.net/stream/vast)
- [Storage Tiers](https://docs.bunny.net/stream/storage-tiers)
- [Replication](https://docs.bunny.net/stream/replication)
- Security


##### Manage Videos

- Upload

- [Collections](https://docs.bunny.net/stream/collections)
- [Tagging](https://docs.bunny.net/stream/tagging)
- [MetaTags](https://docs.bunny.net/stream/metatags)
- [Storage Structure](https://docs.bunny.net/stream/storage-structure)

##### Playback

- Bunny Player

- 3rd Party Players

- Mobile SDK

- [Embedding videos](https://docs.bunny.net/stream/embedding)
- [MP4 Fallback](https://docs.bunny.net/stream/mp4-downloads)

##### Reference

- Tools

- [Statistics](https://docs.bunny.net/stream/statistics)
- [Webhooks](https://docs.bunny.net/stream/webhooks)
- [API Reference](https://docs.bunny.net/api-reference/stream)

On this page

- [How are views counted?](https://docs.bunny.net/stream/statistics#how-are-views-counted)
- [Total views (ViewsChart)](https://docs.bunny.net/stream/statistics#total-views-viewschart)
- [Total watch time (WatchTimeChart)](https://docs.bunny.net/stream/statistics#total-watch-time-watchtimechart)
- [Views per country (CountryViewCounts)](https://docs.bunny.net/stream/statistics#views-per-country-countryviewcounts)
- [Watch time per country (CountryWatchTime)](https://docs.bunny.net/stream/statistics#watch-time-per-country-countrywatchtime)
- [Engagement score](https://docs.bunny.net/stream/statistics#engagement-score)
- [Heatmap](https://docs.bunny.net/stream/statistics#heatmap)
- [All stream statistics are available over the Stream API](https://docs.bunny.net/stream/statistics#all-stream-statistics-are-available-over-the-stream-api)

Reference

# Statistics

Understand video analytics including views, watch time, engagement scores, and heatmaps.

| Dashboard Statistics | Location | Granularity |
| --- | --- | --- |
| Heatmap | Video player | Video |
| Total views | Video library | Video |
| Total watch time | Video library | Video |
| Total views | Statistics | Video library |
| Total watch time | Statistics | Video library |
| Views per country | Statistics | Video library |
| Average watch time per country | Statistics | Video library |
| Data center traffic distribution | Statistics | Video library |
| Bandwidth served | Statistics | Video library |
| Requests served | Statistics | Video library |

### [​](https://docs.bunny.net/stream/statistics\#how-are-views-counted)  How are views counted?

Views are calculated by playback starts, which is counted once per viewer session per video. Safeguards have been implemented to ensure accurate tallying.

### [​](https://docs.bunny.net/stream/statistics\#total-views-viewschart)  Total views (ViewsChart)

Shows the number of playback starts over time, with each data point representing the count of view starts in the corresponding UTC interval (hourly or daily). It’s available at both the library level (aggregated across all videos) and the video level (for a single video). A playback start is counted once per viewer session per video, with empty intervals shown as zero. Safeguards help prevent spam and bot inflation by using per‑session deduplication and filtering of obviously invalid or rapid repeated events.

### [​](https://docs.bunny.net/stream/statistics\#total-watch-time-watchtimechart)  Total watch time (WatchTimeChart)

Shows the cumulative time viewers spent watching over time, with each data point representing total watch time in the corresponding UTC interval (hourly or daily). It is available at both the library level (aggregated across all videos) and the video level (for a single video). Rewatches and repeated visits add to the total, empty intervals are shown as zero, and safeguards help prevent spam and bot inflation by filtering obviously invalid or rapid repeated events.

### [​](https://docs.bunny.net/stream/statistics\#views-per-country-countryviewcounts)  Views per country (CountryViewCounts)

Shows the total number of playback starts by country for the selected time range. It is available at both the library level (aggregated across all videos) and the video level (for a single video). Each country’s value reflects unique playback starts per viewer session based on IP geolocation at playback start. Safeguards help prevent spam and bot inflation by filtering obviously invalid or unknown locations.

### [​](https://docs.bunny.net/stream/statistics\#watch-time-per-country-countrywatchtime)  Watch time per country (CountryWatchTime)

Shows the total watch time by country for the selected time range. It is available at both the library level (aggregated across all videos) and the video level (for a single video). Values reflect cumulative viewing time (rewatches and repeated visits add to the total) based on IP geolocation at playback start. Safeguards help prevent spam and bot inflation by filtering obviously invalid or unknown locations.

### [​](https://docs.bunny.net/stream/statistics\#engagement-score)  Engagement score

Indicates how engaging a specific video is on a 0–100 scale based on viewing duration and viewing patterns. Higher values reflect stronger viewer retention. It is reported at the video level only and may be unavailable when there is not enough viewing data.

### [​](https://docs.bunny.net/stream/statistics\#heatmap)  Heatmap

Visualizes how viewers engage with a specific video over time, highlighting the parts that are watched and rewatched most versus sections with drop‑offs. It’s an aggregate, timeline‑based view of audience attention that helps identify peaks, skips, and retention patterns. The heatmap is available at the video level and may be missing if there isn’t enough viewing data or the feature is disabled.

### [​](https://docs.bunny.net/stream/statistics\#all-stream-statistics-are-available-over-the-stream-api)  [All stream statistics are available over the Stream API](https://docs.bunny.net/api-reference/stream)

Was this page helpful?

YesNo

[Vimeo2Bunny CLI\\
\\
Previous](https://docs.bunny.net/stream/vimeo2bunny) [Webhooks\\
\\
Next](https://docs.bunny.net/stream/webhooks)

Ctrl+I

[discord](https://discord.gg/bunnynet) [github](https://github.com/BunnyWay) [x](https://x.com/BunnyCDN) [bluesky](https://bsky.app/profile/bunny.net) [linkedin](https://www.linkedin.com/company/bunnynet) [facebook](https://www.facebook.com/bunnycdn)

[Powered byThis documentation is built and hosted on Mintlify, a developer documentation platform](https://www.mintlify.com/?utm_campaign=poweredBy&utm_medium=referral&utm_source=bunnynet-cb9733c2)