---
url: "https://docs.bunny.net/stream/mediacage-basic-guide"
title: "Understanding MediaCage basic DRM - bunny.net Documentation"
---

[Skip to main content](https://docs.bunny.net/stream/mediacage-basic-guide#content-area)

[bunny.net Documentation home page![light logo](https://mintcdn.com/bunnynet-cb9733c2/6384LvUK3LN5qH0K/logo/bunny-logo-dark.svg?fit=max&auto=format&n=6384LvUK3LN5qH0K&q=85&s=eba4147ce661ebcfa4c9c02824821548)![dark logo](https://mintcdn.com/bunnynet-cb9733c2/6384LvUK3LN5qH0K/logo/bunny-logo-light.svg?fit=max&auto=format&n=6384LvUK3LN5qH0K&q=85&s=70442c3230eb81060e645a47aebdcc32)](https://docs.bunny.net/)

Stream

[Documentation](https://docs.bunny.net/stream)

- [API Reference](https://docs.bunny.net/api-reference)
- [GitHub](https://github.com/BunnyWay)
- [Get Started](https://dash.bunny.net/auth/register)
- [Get Started](https://dash.bunny.net/auth/register)

Search...

Navigation

MediaCage DRM

Understanding MediaCage basic DRM

Search...

Ctrl K

##### Documentation

- [Introduction](https://docs.bunny.net/stream)
- [Quickstart](https://docs.bunny.net/stream/quickstart)
- [Authentication](https://docs.bunny.net/stream/authentication)
- [Pricing](https://docs.bunny.net/stream/pricing)
- [Changelog](https://docs.bunny.net/stream/changelog)

##### Features

- Encoding

- [Premium Encoding](https://docs.bunny.net/stream/premium-encoding)
- [Transcribing](https://docs.bunny.net/stream/transcribing)
- [Smart Chapters](https://docs.bunny.net/stream/smart-chapters)
- MediaCage DRM

  - [Overview](https://docs.bunny.net/stream/drm)
  - [MediaCage Basic DRM](https://docs.bunny.net/stream/mediacage-basic)
  - [Understanding MediaCage basic DRM](https://docs.bunny.net/stream/mediacage-basic-guide)
  - [Quickstart MediaCage Basic DRM](https://docs.bunny.net/stream/quickstart-mediacage-basic)
  - [MediaCage Enterprise DRM](https://docs.bunny.net/stream/mediacage-enterprise)
  - [Quickstart MediaCage Enterprise DRM](https://docs.bunny.net/stream/quickstart-mediacage-enterprise)
  - [Google Widevine DRM](https://docs.bunny.net/stream/widevine-security-levels)
  - [Google Widevine DRM SD only for L3](https://docs.bunny.net/stream/widevine-l3)
  - [Apple FairPlay Streaming](https://docs.bunny.net/stream/fairplay-deployment)
- [Advertising VAST](https://docs.bunny.net/stream/vast)
- [Storage Tiers](https://docs.bunny.net/stream/storage-tiers)
- [Replication](https://docs.bunny.net/stream/replication)
- Security


##### Manage Videos

- Upload

- [Collections](https://docs.bunny.net/stream/collections)
- [Tagging](https://docs.bunny.net/stream/tagging)
- [MetaTags](https://docs.bunny.net/stream/metatags)
- [Storage Structure](https://docs.bunny.net/stream/storage-structure)

##### Playback

- Bunny Player

- 3rd Party Players

- Mobile SDK

- [Embedding videos](https://docs.bunny.net/stream/embedding)
- [MP4 Fallback](https://docs.bunny.net/stream/mp4-downloads)

##### Reference

- Tools

- [Statistics](https://docs.bunny.net/stream/statistics)
- [Webhooks](https://docs.bunny.net/stream/webhooks)
- [API Reference](https://docs.bunny.net/api-reference/stream)

On this page

- [What is MediaCage?](https://docs.bunny.net/stream/mediacage-basic-guide#what-is-mediacage)
- [Clear-Key Encryption](https://docs.bunny.net/stream/mediacage-basic-guide#clear-key-encryption)
- [Dynamic Key Generation](https://docs.bunny.net/stream/mediacage-basic-guide#dynamic-key-generation)
- [Security Considerations](https://docs.bunny.net/stream/mediacage-basic-guide#security-considerations)
- [Limitations](https://docs.bunny.net/stream/mediacage-basic-guide#limitations)
- [Embed View Only](https://docs.bunny.net/stream/mediacage-basic-guide#embed-view-only)
- [No MP4 Fallback & Early-Play Support](https://docs.bunny.net/stream/mediacage-basic-guide#no-mp4-fallback-%26-early-play-support)

MediaCage DRM

# Understanding MediaCage basic DRM

Learn how MediaCage basic DRM protects your video content from unauthorized downloads.

# [​](https://docs.bunny.net/stream/mediacage-basic-guide\#what-is-mediacage)  What is MediaCage?

MediaCage is a basic free DRM system designed to prevent most attempts at downloading your video content. MediaCage is tightly integrated into Bunny CDN to dynamically encrypt the video content.It was designed to operate as a device-agnostic system and does not require any special hardware or software support on the client.

# [​](https://docs.bunny.net/stream/mediacage-basic-guide\#clear-key-encryption)  Clear-Key Encryption

Unlike enterprise-style DRM systems, MediaCage uses clear-key based keys to encrypt the video files. While the system was designed to make it extremely difficult to download and decrypt the video content, the keys are transferred to the client in a clear format, making them potentially vulnerable to a sophisticated attack.

# [​](https://docs.bunny.net/stream/mediacage-basic-guide\#dynamic-key-generation)  Dynamic Key Generation

To prevent unauthorized access, MediaCage uses dynamic key generation. This means each video session generates a unique set of keys that can only be used once with that specific session. This prevents users from sharing or attempting to decrypt the video streams.

### [​](https://docs.bunny.net/stream/mediacage-basic-guide\#security-considerations)  Security Considerations

While MediaCage was designed to prevent a vast majority of download attempts and successfully tested with the majority of well-known download plugins it is not a replacement for an enterprise-grade DRM system such as PlayReady or Widevine. If you are interested in an enterprise multi-DRM solution, please get in touch with our support team.

# [​](https://docs.bunny.net/stream/mediacage-basic-guide\#limitations)  Limitations

MediaCage is a powerful system. However, to provide the best security possible, it comes with a couple of feature limitations listed below.

# [​](https://docs.bunny.net/stream/mediacage-basic-guide\#embed-view-only)  Embed View Only

To offer a secure environment, MediaCage requires playback to be made through our Embed View only. Trying to access the videos directly or within a third-party video player will be disabled.

# [​](https://docs.bunny.net/stream/mediacage-basic-guide\#no-mp4-fallback-&-early-play-support)  No MP4 Fallback & Early-Play Support

Due to lack of security and data protection, MP4 fallback and Early-Play are disabled if MediaCage is active on the video library.

Was this page helpful?

YesNo

[MediaCage Basic DRM\\
\\
Previous](https://docs.bunny.net/stream/mediacage-basic) [Quickstart MediaCage Basic DRM\\
\\
Next](https://docs.bunny.net/stream/quickstart-mediacage-basic)

Ctrl+I

[discord](https://discord.gg/bunnynet) [github](https://github.com/BunnyWay) [x](https://x.com/BunnyCDN) [bluesky](https://bsky.app/profile/bunny.net) [linkedin](https://www.linkedin.com/company/bunnynet) [facebook](https://www.facebook.com/bunnycdn)

[Powered byThis documentation is built and hosted on Mintlify, a developer documentation platform](https://www.mintlify.com/?utm_campaign=poweredBy&utm_medium=referral&utm_source=bunnynet-cb9733c2)