---
url: "https://docs.bunny.net/stream/playback-api"
title: "Playback control API - bunny.net Documentation"
---

[Skip to main content](https://docs.bunny.net/stream/playback-api#content-area)

[bunny.net Documentation home page![light logo](https://mintcdn.com/bunnynet-cb9733c2/6384LvUK3LN5qH0K/logo/bunny-logo-dark.svg?fit=max&auto=format&n=6384LvUK3LN5qH0K&q=85&s=eba4147ce661ebcfa4c9c02824821548)![dark logo](https://mintcdn.com/bunnynet-cb9733c2/6384LvUK3LN5qH0K/logo/bunny-logo-light.svg?fit=max&auto=format&n=6384LvUK3LN5qH0K&q=85&s=70442c3230eb81060e645a47aebdcc32)](https://docs.bunny.net/)

Stream

[Documentation](https://docs.bunny.net/stream)

- [API Reference](https://docs.bunny.net/api-reference)
- [GitHub](https://github.com/BunnyWay)
- [Get Started](https://dash.bunny.net/auth/register)
- [Get Started](https://dash.bunny.net/auth/register)

Search...

Navigation

Bunny Player

Playback control API

Search...

Ctrl K

##### Documentation

- [Introduction](https://docs.bunny.net/stream)
- [Quickstart](https://docs.bunny.net/stream/quickstart)
- [Authentication](https://docs.bunny.net/stream/authentication)
- [Pricing](https://docs.bunny.net/stream/pricing)
- [Changelog](https://docs.bunny.net/stream/changelog)

##### Features

- Encoding

- [Premium Encoding](https://docs.bunny.net/stream/premium-encoding)
- [Transcribing](https://docs.bunny.net/stream/transcribing)
- [Smart Chapters](https://docs.bunny.net/stream/smart-chapters)
- MediaCage DRM

- [Advertising VAST](https://docs.bunny.net/stream/vast)
- [Storage Tiers](https://docs.bunny.net/stream/storage-tiers)
- [Replication](https://docs.bunny.net/stream/replication)
- Security


##### Manage Videos

- Upload

- [Collections](https://docs.bunny.net/stream/collections)
- [Tagging](https://docs.bunny.net/stream/tagging)
- [MetaTags](https://docs.bunny.net/stream/metatags)
- [Storage Structure](https://docs.bunny.net/stream/storage-structure)

##### Playback

- Bunny Player

  - [Overview](https://docs.bunny.net/stream/player-settings)
  - [Player](https://docs.bunny.net/stream/player)
  - [Playback control API](https://docs.bunny.net/stream/playback-api)
  - [Custom head HTML migration guide](https://docs.bunny.net/stream/custom-head-html-migration-guide)
- 3rd Party Players

- Mobile SDK

- [Embedding videos](https://docs.bunny.net/stream/embedding)
- [MP4 Fallback](https://docs.bunny.net/stream/mp4-downloads)

##### Reference

- Tools

- [Statistics](https://docs.bunny.net/stream/statistics)
- [Webhooks](https://docs.bunny.net/stream/webhooks)
- [API Reference](https://docs.bunny.net/api-reference/stream)

On this page

- [Quickstart](https://docs.bunny.net/stream/playback-api#quickstart)
- [Methods](https://docs.bunny.net/stream/playback-api#methods)
- [Events](https://docs.bunny.net/stream/playback-api#events)
- [Event list](https://docs.bunny.net/stream/playback-api#event-list)

Bunny Player

# Playback control API

The Bunny Stream Player offers a rich set of events and methods through its embeddable iframe player, enabling external programmatic interaction with playback sessions. To ensure standardization and ease of integration, the embeddable iframe player employs the player.js JavaScript library.

For more information, see detailed documentation available at [player.js website](https://github.com/embedly/player.js#playerjs).

Player.js library is hosted on Bunny.net CDN so you can easily integrate it in your website by including the following script block in your HTML:

```
<script
  type="text/javascript"
  src="//assets.mediadelivery.net/playerjs/playerjs-latest.min.js"
>
</script>
```

## [​](https://docs.bunny.net/stream/playback-api\#quickstart)  Quickstart

After loading the library and embedding the Player iframe, you can create a player object and interact with it using various events and methods. The following example illustrates the basic usage:

```
const player = new playerjs.Player("iframe");

player.on("ready", () => {
  player.on("play", () => {
    console.log("play");
  });

  player.getDuration((duration) => console.log(duration));

  if (player.supports("method", "mute")) {
    player.mute();
  }

  player.play();
});
```

## [​](https://docs.bunny.net/stream/playback-api\#methods)  Methods

The Bunny Stream Player provides the following methods for controlling playback:`play`: Play the media. Example:

```
player.play();
```

`pause`: Pause the media. Example:

```
player.pause();
```

`getPaused`: boolean - Determine if the media is paused. Example:

```
player.getPaused((value) => console.log("paused", value));
```

`mute`: Mute the media. Example:

```
player.mute();
```

`unmute`: Unmute the media. Example:

```
player.unmute();
```

`getMuted`: boolean - Determine if the media is muted. Example:

```
player.getMuted((value) => console.log("muted", value));
```

`setVolume`: Set the volume. Value needs to be between 0-100. Example:

```
player.setVolume(50);
```

`getVolume`: number - Get the volume. Value will be between 0-100. Example:

```
player.getVolume((value) => console.log("getVolume", value));
```

`getDuration`: number - Get the duration of the media is seconds. Example:

```
player.getDuration((value) => console.log("getDuration", value));
```

`setCurrentTime`: number - Perform a seek to a particular time in seconds. Example:

```
player.setCurrentTime(50);
```

`getCurrentTime`: number - Get the current time in seconds of the video. Example:

```
player.getCurrentTime((value) => console.log("getCurrentTime", value));
```

`off`: Remove an event listener. If the listener is specified it should remove only that listener, otherwise remove all listeners. Example:

```
player.off("play");
player.off("play", playCallback);
```

`on`: Add an event listener. Example:

```
player.on("play", () => console.log("play"));
```

`supports`: \[‘method’, ‘event’\], methodOrEventName - Determines if the player supports a given event or method. Example:

```
player.supports("method", "getDuration");
player.supports("event", "ended");
```

## [​](https://docs.bunny.net/stream/playback-api\#events)  Events

The Bunny Stream Player provides a set of events that can be used to enhance and customize your media playback experience. These events can be attached using the `on`method in the player.js script.

### [​](https://docs.bunny.net/stream/playback-api\#event-list)  Event list

The Bunny Stream Player emits the following player.js events that can be attached using the `on`method:`ready`\- Fired when the media is ready to receive commands.

As outlined in the PlayerJs Spec, there may be inconsistencies if multiple players on the page have the same source `src`. To address this, append a UUID or a timestamp to the iframe’s `src`to ensure all players on the page have a unique source.

fired when the media is ready to receive commands. This is fired regardless of listening to the event. Note: As outlined in the PlayerJs Spec, you may run into inconsistencies if you have multiple players on the page with the same `src`. To get around this, simply append a UUID or a timestamp to the iframe’s src to guarantee that all players on the page have a unique `src`.`progress`\- Fires when the media is loading additional media for playback. Example:

```
{
  "percent": 0.8
}
```

`timeupdate` \- Fires during playback. Example:

```
data: {
  seconds: 10,
  duration: 40
}
```

`play`\- Fires when the video starts to play.`pause`\- Fires when the video is paused.`ended`\- Fires when the video is finished.`seeked` \- Fires when the video has been seeked by the user.`error` \- Fires when an error occurs.

Was this page helpful?

YesNo

[Player\\
\\
Previous](https://docs.bunny.net/stream/player) [Custom head HTML migration guide\\
\\
Next](https://docs.bunny.net/stream/custom-head-html-migration-guide)

Ctrl+I

[discord](https://discord.gg/bunnynet) [github](https://github.com/BunnyWay) [x](https://x.com/BunnyCDN) [bluesky](https://bsky.app/profile/bunny.net) [linkedin](https://www.linkedin.com/company/bunnynet) [facebook](https://www.facebook.com/bunnycdn)

[Powered byThis documentation is built and hosted on Mintlify, a developer documentation platform](https://www.mintlify.com/?utm_campaign=poweredBy&utm_medium=referral&utm_source=bunnynet-cb9733c2)