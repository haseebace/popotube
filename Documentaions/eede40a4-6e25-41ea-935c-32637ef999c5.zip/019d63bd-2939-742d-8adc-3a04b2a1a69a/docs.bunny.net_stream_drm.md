---
url: "https://docs.bunny.net/stream/drm"
title: "MediaCage DRM - bunny.net Documentation"
---

[Skip to main content](https://docs.bunny.net/stream/drm#content-area)

[bunny.net Documentation home page![light logo](https://mintcdn.com/bunnynet-cb9733c2/6384LvUK3LN5qH0K/logo/bunny-logo-dark.svg?fit=max&auto=format&n=6384LvUK3LN5qH0K&q=85&s=eba4147ce661ebcfa4c9c02824821548)![dark logo](https://mintcdn.com/bunnynet-cb9733c2/6384LvUK3LN5qH0K/logo/bunny-logo-light.svg?fit=max&auto=format&n=6384LvUK3LN5qH0K&q=85&s=70442c3230eb81060e645a47aebdcc32)](https://docs.bunny.net/)

Stream

[Documentation](https://docs.bunny.net/stream)

- [API Reference](https://docs.bunny.net/api-reference)
- [GitHub](https://github.com/BunnyWay)
- [Get Started](https://dash.bunny.net/auth/register)
- [Get Started](https://dash.bunny.net/auth/register)

Search...

Navigation

MediaCage DRM

MediaCage DRM

Search...

Ctrl K

##### Documentation

- [Introduction](https://docs.bunny.net/stream)
- [Quickstart](https://docs.bunny.net/stream/quickstart)
- [Authentication](https://docs.bunny.net/stream/authentication)
- [Pricing](https://docs.bunny.net/stream/pricing)
- [Changelog](https://docs.bunny.net/stream/changelog)

##### Features

- Encoding

- [Premium Encoding](https://docs.bunny.net/stream/premium-encoding)
- [Transcribing](https://docs.bunny.net/stream/transcribing)
- [Smart Chapters](https://docs.bunny.net/stream/smart-chapters)
- MediaCage DRM

  - [Overview](https://docs.bunny.net/stream/drm)
  - [MediaCage Basic DRM](https://docs.bunny.net/stream/mediacage-basic)
  - [Understanding MediaCage basic DRM](https://docs.bunny.net/stream/mediacage-basic-guide)
  - [Quickstart MediaCage Basic DRM](https://docs.bunny.net/stream/quickstart-mediacage-basic)
  - [MediaCage Enterprise DRM](https://docs.bunny.net/stream/mediacage-enterprise)
  - [Quickstart MediaCage Enterprise DRM](https://docs.bunny.net/stream/quickstart-mediacage-enterprise)
  - [Google Widevine DRM](https://docs.bunny.net/stream/widevine-security-levels)
  - [Google Widevine DRM SD only for L3](https://docs.bunny.net/stream/widevine-l3)
  - [Apple FairPlay Streaming](https://docs.bunny.net/stream/fairplay-deployment)
- [Advertising VAST](https://docs.bunny.net/stream/vast)
- [Storage Tiers](https://docs.bunny.net/stream/storage-tiers)
- [Replication](https://docs.bunny.net/stream/replication)
- Security


##### Manage Videos

- Upload

- [Collections](https://docs.bunny.net/stream/collections)
- [Tagging](https://docs.bunny.net/stream/tagging)
- [MetaTags](https://docs.bunny.net/stream/metatags)
- [Storage Structure](https://docs.bunny.net/stream/storage-structure)

##### Playback

- Bunny Player

- 3rd Party Players

- Mobile SDK

- [Embedding videos](https://docs.bunny.net/stream/embedding)
- [MP4 Fallback](https://docs.bunny.net/stream/mp4-downloads)

##### Reference

- Tools

- [Statistics](https://docs.bunny.net/stream/statistics)
- [Webhooks](https://docs.bunny.net/stream/webhooks)
- [API Reference](https://docs.bunny.net/api-reference/stream)

On this page

- [MediaCage Basic DRM](https://docs.bunny.net/stream/drm#mediacage-basic-drm)
- [Key features](https://docs.bunny.net/stream/drm#key-features)
- [MediaCage Enterprise DRM](https://docs.bunny.net/stream/drm#mediacage-enterprise-drm)
- [Key features](https://docs.bunny.net/stream/drm#key-features-2)
- [FairPlay streaming](https://docs.bunny.net/stream/drm#fairplay-streaming)
- [Widevine](https://docs.bunny.net/stream/drm#widevine)
- [Pricing](https://docs.bunny.net/stream/drm#pricing)
- [One simple plan: $99/month plus DRM-license fees](https://docs.bunny.net/stream/drm#one-simple-plan-%2499%2Fmonth-plus-drm-license-fees)
- [What counts as a DRM-license?](https://docs.bunny.net/stream/drm#what-counts-as-a-drm-license)
- [Monthly cost calculation example](https://docs.bunny.net/stream/drm#monthly-cost-calculation-example)

MediaCage DRM

# MediaCage DRM

MediaCage DRM (Digital Rights Management) solutions are designed to safeguard your digital content and protect it from unauthorized access and distribution.

Bunny Stream offers two distinct media content protection tiers: **MediaCage Basic DRM** and **MediaCage Enterprise DRM**. Each product is tailored to meet different security needs, providing you with the flexibility to choose the level of protection that aligns with your specific requirements.

| Feature | MediaCage Basic DRM | MediaCage Enterprise DRM |
| --- | --- | --- |
| Browser support | ✅ | ✅ |
| Native platform support |  | ✅ |
| Clear key encryption | ✅ |  |
| Secure key management |  | ✅ |
| Download protection | ✅ | ✅ |
| Screen grab protection |  | ✅ |
| Custom player support |  | ✅ |

\* _Screen Grab Protection is not available on Widevine clients with L3 level of security. For a deeper understanding, refer to [Widevine DRM Security Levels](https://docs.bunny.net/docs/widevine-drm-security-levels)._

# [​](https://docs.bunny.net/stream/drm\#mediacage-basic-drm)  MediaCage Basic DRM

**MediaCage Basic DRM** is a basic protection solution and it serves as an entry-level digital content protection solution. It employs innovative dynamic encryption, ensuring that your content is encrypted on demand. This encryption process occurs internally, securing your content as it traverses the network to reach your users.

## [​](https://docs.bunny.net/stream/drm\#key-features)  Key features

- **Dynamic encryption**: Utilizes an innovative dynamic clear key encryption for on-demand content protection.
- **Download prevention**: MediaCage Basic DRM employs a special mechanism to prevent download of media files.
- **Session-based content key protection**: The content is encrypted with a unique key for each play session.

**MediaCage Basic DRM** is suitable for scenarios where basic content protection is required. It is an innovative solution for users seeking entry-level security measures for their digital content.

# [​](https://docs.bunny.net/stream/drm\#mediacage-enterprise-drm)  MediaCage Enterprise DRM

**MediaCage Enterprise DRM** is an advanced protection feature which represents our advanced digital content protection solution, offering an elevated level of security for enterprise-level requirements. It incorporates underlying industry standard technologies ( [FairPlay Streaming](https://developer.apple.com/streaming/fps/) and [Widevine](https://www.widevine.com/)), providing enhanced encryption and protection features.

![](https://mintcdn.com/bunnynet-cb9733c2/JS4E0kUrTdMvF5UC/images/docs/6f3c031-DRM_enterprise_.png?fit=max&auto=format&n=JS4E0kUrTdMvF5UC&q=85&s=0d7f74e4729afe6f4a0d81134be9aa0d)

MediaCage Enterprise DRM workflow

**Enterprise Media Cage DRM** is designed to meet the stringent security needs of organizations that demand the highest level of content protection.In comparison to our MediaCage Basic DRM, the MediaCage Enterprise DRM protects the content also on client devices using hardware vendor support for protecting content key during the playback.

## [​](https://docs.bunny.net/stream/drm\#key-features-2)  Key features

- **Automatic encryption during packaging**: Content is automatically protected during the transcoding process.
- **Advanced encryption technologies**: Utilizes FairPlay (Apple) and Widevine (Google) for superior content encryption.
- **Hardware-based key exchange**: Ensures secure content key is not exposed on client devices.
- **Screen grab protection**: Prevents screenshots and screen recordings, so that content cannot be copied. Bear in mind that Screen Grab Protection is not available on Widevine clients with L3 level of security. For a deeper understanding, refer to [Widevine DRM Security Levels](https://docs.bunny.net/docs/widevine-drm-security-levels).
- **Premium content licensing**: Ensures that a valid play license is issued only to authenticated clients that meet protection level requirements.
- **Adherence to industry standards**: Meets advanced industry standards for digital content protection. Tailored for Enterprise Security: Specifically designed to address the security needs of enterprise-level users.
- **Multi-key DRM**: Multi-key DRM licensing is implemented on a per-playback-device basis, allowing multiple licenses to be issued for a single piece of video content.For example, a single playback device may receive two separate licenses. One for the video stream and another for the accompanying stereo audio track; resulting in a total of two DRM licenses being issued and billed.

**Media Cage Enterprise DRM** is the ideal choice for organizations with high-security demands, seeking advanced protection mechanisms and adherence to industry standards. It is suitable for scenarios where content integrity is of utmost importance, and enterprise-level security is a priority.**Supported browsers for Widevine and Fairplay:**

| Browser | Widevine | FairPlay Streaming |
| --- | --- | --- |
| Microsoft Edge | ✅ |  |
| Chrome | ✅ |  |
| Firefox | ✅ |  |
| Safari |  | ✅ |
| Android | ✅ |  |
| iOS |  | ✅ |

## [​](https://docs.bunny.net/stream/drm\#fairplay-streaming)  FairPlay streaming

**FairPlay streaming**, a technology developed by Apple, is an underlying component of our MediaCage Enterprise DRM solution. It provides a highly secure mechanism for content protection on Apple devices. This hardware-centric approach significantly enhances the overall security of your content, limiting key exchanges to Apple devices, including Macs, iPhones, iPads, and Apple TV.

To learn more about FairPlay streaming, see the official [FPS\\
website](https://developer.apple.com/streaming/fps/).

To use FairPlay Streaming to deliver your content you have to request the FPS Deployment Package from Apple. You can get more information about the process in our FairPlay Streaming Certificate Registration guide.

## [​](https://docs.bunny.net/stream/drm\#widevine)  Widevine

Widevine provides digital media solutions for the delivery of digital entertainment to a wide range of device platforms. Widevine is integrated into our MediaCage Enterprise DRM solution. The technology is built-in a number of device platforms such as Windows, Android, ChromeOS and browsers such as Chrome, Firefox, Edge…

To learn more about Widevine technology, see the [official Widevine\\
documentation portal](https://developers.google.com/widevine).

## [​](https://docs.bunny.net/stream/drm\#pricing)  Pricing

### [​](https://docs.bunny.net/stream/drm\#one-simple-plan-$99/month-plus-drm-license-fees)  One simple plan: $99/month plus DRM-license fees

Our unique pricing model consists of a base fee of $99 per month, coupled with additional costs for DRM-license fees. This approach allows you to pay only for what you use, ensuring that your costs are always aligned with your actual consumption of DRM licenses. This means you only pay for the licenses you use, in addition to the monthly base fee.We employ a tiered pricing strategy for DRM licenses to provide you with the most cost-efficient solution possible. The cost per license decreases as your volume of licenses increases, as detailed below:

| Licenses/Month | Cost per license |
| --- | --- |
| Up to 20,000: | $0.005 |
| 20,001 to 100,000: | $0.004 per license |
| 100,001 to 500,000: | $0.003 per license |
| Over 500,000: | Please contact us for custom pricing |

This usage-based model allows for significant flexibility and control over your costs, making it easier to budget and plan for your DRM needs.

Enterprise DRM ensures that videos are encrypted during the transcoding process and stored securely in the storage.**Multi-key DRM** For example, a single playback device may receive two separate licenses. One for the video stream and another for the accompanying stereo audio track; resulting in a total of two DRM licenses being issued and billed.

### [​](https://docs.bunny.net/stream/drm\#what-counts-as-a-drm-license)  What counts as a DRM-license?

A DRM license is issued each time a user initiates playback of a video that requires a DRM (Digital Rights Management) license for decryption. Our system is designed to count licenses in a manner that ensures fairness and cost-effectiveness:

- Multi-key DRM licensing is implemented on a per-playback-device basis, allowing multiple licenses to be issued for a single piece of video content per playback device. The video and audio tracks can be issued a separate license.
- Each unique VoD (Video on Demand) content playback on a device counts as one DRM license.
- SD videos or audio streams do not incur DRM license fees.

**Examples:**

- **Multiple browser playback**: If a user plays back a video in HD and then restarts the VoD session in a different browser, it counts as 2 DRM licenses.
- **Playlist viewing**: Watching a playlist with 5 HD VoD videos results in 5 DRM licenses, one for each video.
- **Resolution upgrade**: A video played in UHD typically incurs 2 DRM license requests if the player initially starts in SD or HD before switching to UHD.
- **SD resolution**: Watching a video in SD resolution does not count towards DRM license usage.

### [​](https://docs.bunny.net/stream/drm\#monthly-cost-calculation-example)  Monthly cost calculation example

To illustrate, if 10,000 users each watch 15 HD videos in a month, this results in 150,000 DRM licenses. Applying the tiered pricing model, the cost for 150,000 licenses amounts to $669.**Example:**(20,000 x 0.005) + (80,000 x 0.004) + (50,000 x 0.003) = 100 + 320 + 150 = 570+570 + 570+99 base fee = **$669**

Was this page helpful?

YesNo

[Smart Chapters\\
\\
Previous](https://docs.bunny.net/stream/smart-chapters) [MediaCage Basic DRM\\
\\
Next](https://docs.bunny.net/stream/mediacage-basic)

Ctrl+I

[discord](https://discord.gg/bunnynet) [github](https://github.com/BunnyWay) [x](https://x.com/BunnyCDN) [bluesky](https://bsky.app/profile/bunny.net) [linkedin](https://www.linkedin.com/company/bunnynet) [facebook](https://www.facebook.com/bunnycdn)

[Powered byThis documentation is built and hosted on Mintlify, a developer documentation platform](https://www.mintlify.com/?utm_campaign=poweredBy&utm_medium=referral&utm_source=bunnynet-cb9733c2)

![](https://mintcdn.com/bunnynet-cb9733c2/JS4E0kUrTdMvF5UC/images/docs/6f3c031-DRM_enterprise_.png?w=840&fit=max&auto=format&n=JS4E0kUrTdMvF5UC&q=85&s=00713e659582bfefe02817fa165882e0)