---
url: "https://docs.bunny.net/stream"
title: "Bunny Stream - bunny.net Documentation"
---

[Skip to main content](https://docs.bunny.net/stream#content-area)

[bunny.net Documentation home page![light logo](https://mintcdn.com/bunnynet-cb9733c2/6384LvUK3LN5qH0K/logo/bunny-logo-dark.svg?fit=max&auto=format&n=6384LvUK3LN5qH0K&q=85&s=eba4147ce661ebcfa4c9c02824821548)![dark logo](https://mintcdn.com/bunnynet-cb9733c2/6384LvUK3LN5qH0K/logo/bunny-logo-light.svg?fit=max&auto=format&n=6384LvUK3LN5qH0K&q=85&s=70442c3230eb81060e645a47aebdcc32)](https://docs.bunny.net/)

Stream

[Documentation](https://docs.bunny.net/stream)

- [API Reference](https://docs.bunny.net/api-reference)
- [GitHub](https://github.com/BunnyWay)
- [Get Started](https://dash.bunny.net/auth/register)
- [Get Started](https://dash.bunny.net/auth/register)

Search...

Navigation

Documentation

Bunny Stream

Search...

Ctrl K

##### Documentation

- [Introduction](https://docs.bunny.net/stream)
- [Quickstart](https://docs.bunny.net/stream/quickstart)
- [Authentication](https://docs.bunny.net/stream/authentication)
- [Pricing](https://docs.bunny.net/stream/pricing)
- [Changelog](https://docs.bunny.net/stream/changelog)

##### Features

- Encoding

- [Premium Encoding](https://docs.bunny.net/stream/premium-encoding)
- [Transcribing](https://docs.bunny.net/stream/transcribing)
- [Smart Chapters](https://docs.bunny.net/stream/smart-chapters)
- MediaCage DRM

- [Advertising VAST](https://docs.bunny.net/stream/vast)
- [Storage Tiers](https://docs.bunny.net/stream/storage-tiers)
- [Replication](https://docs.bunny.net/stream/replication)
- Security


##### Manage Videos

- Upload

- [Collections](https://docs.bunny.net/stream/collections)
- [Tagging](https://docs.bunny.net/stream/tagging)
- [MetaTags](https://docs.bunny.net/stream/metatags)
- [Storage Structure](https://docs.bunny.net/stream/storage-structure)

##### Playback

- Bunny Player

- 3rd Party Players

- Mobile SDK

- [Embedding videos](https://docs.bunny.net/stream/embedding)
- [MP4 Fallback](https://docs.bunny.net/stream/mp4-downloads)

##### Reference

- Tools

- [Statistics](https://docs.bunny.net/stream/statistics)
- [Webhooks](https://docs.bunny.net/stream/webhooks)
- [API Reference](https://docs.bunny.net/api-reference/stream)

On this page

- [Key features](https://docs.bunny.net/stream#key-features)

Documentation

# Bunny Stream

Video streaming platform with global delivery, adaptive streaming, and robust security.

![bunny.net Stream](https://mintcdn.com/bunnynet-cb9733c2/pejm9TO_6AWok4yv/images/stream/stream.png?fit=max&auto=format&n=pejm9TO_6AWok4yv&q=85&s=f066d94813817c2be029d592019e0a73)Bunny Stream is a feature-rich video streaming platform that allows content creators, website owners, and businesses to easily upload, manage, and stream video content to audiences worldwide. Built on top of bunny.net’s robust content delivery network (CDN), Bunny Stream ensures that your video content is delivered efficiently and smoothly, regardless of the viewers’ location.

[**Stream Quickstart**](https://docs.bunny.net/stream/quickstart)

## [​](https://docs.bunny.net/stream\#key-features)  Key features

Bunny Stream is designed to offer a seamless video streaming experience. Here are some of its key features:

- **Global delivery**: Utilizes bunny.net’s extensive CDN to stream videos with low latency and high transfer speeds globally.
- **Adaptive streaming**: Automatically adjusts video quality based on the viewer’s internet speed, ensuring uninterrupted playback.
- **Video management**: Offers a user-friendly dashboard for uploading, organizing, and managing video content.
- **Encoding and transcoding**: Automatically converts videos into multiple resolutions and formats to ensure compatibility across devices and browsers.
- **Customizable video player**: Provides a customizable video player that can be tailored to match your branding and website design.
- **Security**: Features security measures such as token authentication and domain restrictions to protect your video content from unauthorized access.
- **DRM**: Implements DRM solutions to further secure your video content against piracy and unauthorized distribution, ensuring that your content is viewed only by authorized users in authorized regions. For more information, see our [MediaCageDRM overview](https://docs.bunny.net/docs/stream-drm).
- **Statistics**: Track engagement and analyze viewer behavior with detailed analytics and reporting tools.

Was this page helpful?

YesNo

[Quickstart\\
\\
Next](https://docs.bunny.net/stream/quickstart)

Ctrl+I

[discord](https://discord.gg/bunnynet) [github](https://github.com/BunnyWay) [x](https://x.com/BunnyCDN) [bluesky](https://bsky.app/profile/bunny.net) [linkedin](https://www.linkedin.com/company/bunnynet) [facebook](https://www.facebook.com/bunnycdn)

[Powered byThis documentation is built and hosted on Mintlify, a developer documentation platform](https://www.mintlify.com/?utm_campaign=poweredBy&utm_medium=referral&utm_source=bunnynet-cb9733c2)

![bunny.net Stream](https://mintcdn.com/bunnynet-cb9733c2/pejm9TO_6AWok4yv/images/stream/stream.png?w=840&fit=max&auto=format&n=pejm9TO_6AWok4yv&q=85&s=d421198eb88c160a238ddde7bc541538)